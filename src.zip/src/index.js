import * as React from 'react';
import { createRoot } from 'react-dom/client';
import { Component } from 'react-simplified';
import { NavLink, HashRouter, Route } from 'react-router-dom';
import { pool } from './mysql-pool';

class Menu extends Component {
  render() {
    return (
      <div>
        <NavLink exact to="/" activeStyle={{ color: 'darkblue' }}>
          StudAdm
        </NavLink>{' '}
        <NavLink to="/students" activeStyle={{ color: 'darkblue' }}>
          Students
        </NavLink>{' '}
        <NavLink to="/programs" activeStyle={{ color: 'darkblue' }}>
          Programs
        </NavLink>
      </div>
    );
  }
}

class Home extends Component {
  render() {
    return <div>Welcome to StudAdm</div>;
  }
}

class StudentList extends Component {
  students = [];

  render() {
    return (
      <ul>
        {this.students.map((student) => (
          <li key={student.id}>
            <NavLink to={'/students/' + student.id}>{student.name}</NavLink>
          </li>
        ))}
      </ul>
    );
  }

  mounted() {
    pool.query('SELECT id, name FROM Students', (error, results) => {
      if (error) return console.error(error);

      this.students = results;
    });
  }
}

class StudentDetails extends Component {
  student = null;
  program = null;

  render() {
    if (!this.student || !this.program) return null;

    return (
      <div>
        <h2>Student details:</h2>
        <ul>
          <li>Name: {this.student.name}</li>
          <li>Email: {this.student.email}</li>
        </ul>

        <h2>Associated program:</h2>
        <p>{this.program.name}</p>
      </div>
    );
  }

  mounted() {
    let studentId = this.props.match.params.id;

    pool.query(
      'SELECT s.name AS student_name, s.email, p.name AS program_name FROM Students s INNER JOIN Programs p ON s.program_id = p.id WHERE s.id=?',
      [studentId],
      (error, results) => {
        if (error) return console.error(error);

        if (results.length > 0) {
          this.student = { name: results[0].student_name, email: results[0].email };
          this.program = { name: results[0].program_name };
        }
      },
    );
  }
}

class ProgramList extends Component {
  programs = [];

  render() {
    return (
      <ul>
        {this.programs.map((program) => (
          <li key={program.id}>
            <NavLink to={'/programs/' + program.id}>{program.name}</NavLink>
          </li>
        ))}
      </ul>
    );
  }

  mounted() {
    pool.query('SELECT id, name FROM Programs', (error, results) => {
      if (error) return console.error(error);

      this.programs = results;
    });
  }
}

class ProgramDetails extends Component {
  program = null;
  students = [];

  render() {
    if (!this.program) return null;

    return (
      <div>
        <h2>Program details:</h2>
        <ul>
          <li>Name: {this.program.name}</li>
          <li>Code: {this.program.code}</li>
        </ul>

        <h2>Students:</h2>
        <ul>
          {this.students.map((student) => (
            <li key={student.id}>{student.name}</li>
          ))}
        </ul>
      </div>
    );
  }

  mounted() {
    let programId = this.props.match.params.id;

    pool.query('SELECT name, code FROM Programs WHERE id=?', [programId], (error, results) => {
      if (error) return console.error(error);

      this.program = results[0];
    });

    pool.query('SELECT name FROM Students WHERE program_id=?', [programId], (error, results) => {
      if (error) return console.error(error);

      this.students = results;
    });
  }
}

createRoot(document.getElementById('root')).render(
  <HashRouter>
    <div>
      <Menu />
      <Route exact path="/" component={Home} />
      <Route exact path="/students" component={StudentList} />
      <Route exact path="/students/:id" component={StudentDetails} />
      <Route exact path="/programs" component={ProgramList} />
      <Route exact path="/programs/:id" component={ProgramDetails} />
    </div>
  </HashRouter>,
);
